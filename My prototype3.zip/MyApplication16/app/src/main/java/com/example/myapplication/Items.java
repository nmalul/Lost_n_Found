package com.example.myapplication;

public class Items {
    private String item;

    public Items(String item){
        this.item=item;
    }
    public String getItem(){
        return this.item;
    }
    public void setItem(String item){
        this.item=item;
    }
}
