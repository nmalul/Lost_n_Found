package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
Button btnEditItems;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnEditItems=findViewById(R.id.btnEditItems);
        btnEditItems.setOnClickListener(this);
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){
        super.onOptionsItemSelected(item);
        int id=item.getItemId();
        if(id==R.id.action_login){
            Intent intent=new Intent(this,LoginActivity.class);
            startActivityForResult(intent,2);
        }
        return true;
    }

    @Override
    public void onClick(View v) {
        if(v==btnEditItems){
            Intent intent=new Intent(this,EditItemsActivity.class);
            startActivityForResult(intent,0);
        }
    }

}